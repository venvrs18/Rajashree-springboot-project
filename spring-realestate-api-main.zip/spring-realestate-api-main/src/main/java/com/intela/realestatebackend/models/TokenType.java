package com.intela.realestatebackend.models;

public enum TokenType {
    ACCESS,
    REFRESH
}
